Arduino Cloud historic data

variables:
  - id: 9501d334-286f-4889-beb5-4ac7c738c807
    name: xLamp_button
    thingName: Modbus RTU pomiar energii
  - id: b2039050-78cd-4514-97cc-a1e8d7ae1124
    name: xHeater_button
    thingName: Modbus RTU pomiar energii
  - id: cf02a6ce-22b0-42c5-849a-168294ce00df
    name: iVoltage
    thingName: Modbus RTU pomiar energii
  - id: 7370892f-be30-4516-8701-44cfb8121a29
    name: xVentilator_button
    thingName: Modbus RTU pomiar energii
  - id: f59dbd64-6964-4306-9070-ab505097f62d
    name: iCurrent
    thingName: Modbus RTU pomiar energii
  - id: 89dcc706-3ebd-4d0a-9608-aa7e357e915b
    name: iPower
    thingName: Modbus RTU pomiar energii
  - id: 32f217ea-c2c0-44a3-a393-436e35cc65a2
    name: iFreq
    thingName: Modbus RTU pomiar energii
  - id: 4a9e96bf-097f-46fe-8f6f-60baf1395af0
    name: energy
    thingName: Modbus RTU pomiar energii
from: 2024-07-07T00:00:00Z
to: 2024-07-12T23:59:59Z

Have fun! :)
